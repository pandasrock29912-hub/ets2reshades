#!/usr/bin/env python3
"""
ETS2 :: PHOTOREALISM - LUT generator
====================================

Builds the 1024x32 strip LUT that ReShade's LUT.fx expects
(fLUT_TileSizeXY=32, fLUT_TileAmount=32, texture Width = 32*32 = 1024).

Layout convention (verified against ReShade's own stock Textures/lut.png,
which is a pure identity LUT):

    pixel x = tile * 32 + i      pixel y = j
    entry   = grade( i/31, j/31, tile/31 )
    value   = round(out * 255)

so all three axes are 32 samples across [0,1] with a step of 1/31.

The grade itself is deliberately conservative - it is a *camera profile*,
not an Instagram filter. Everything it does is a few percent:

  1. highlight shoulder      soft roll-off above 0.78 (no clipped neon whites)
  2. split tone              cool shadows / warm highlights (RGB, by luma)
  3. hue shaping             foliage -> olive & darker, sky keeps its depth
                             (purple nudge removed), warm tones kept alive
  4. global saturation x0.94 games oversaturate, real sensors do not
  5. black floor             1/255 lift: film has no true zero

Usage:  python3 generate_lut.py [output.png]
"""

import math
import os
import sys

from PIL import Image

TILE = 32          # fLUT_TileSizeXY
TILES = 32         # fLUT_TileAmount
WIDTH = TILE * TILES
HEIGHT = TILE
STEPS = TILE - 1   # 31 -> step of 1/31

# ---------------------------------------------------------------- tone ----
SHOULDER_START = 0.78
SHOULDER_K = 1.15          # >1 = compress highlights slightly

BLACK_FLOOR = 0.004         # ~1/255

# ----------------------------------------------------------- split tone ---
# delta = luma - 0.5  -> positive = highlights, negative = shadows
SPLIT_R = 0.030             # highlights warm
SPLIT_G = 0.006
SPLIT_B = -0.030            # shadows cool

# ---------------------------------------------------------- hue shaping ---
GLOBAL_SAT = 0.94

# (hue centre, half width, feather, sat scale, hue shift deg, value scale)
HUE_BANDS = [
    # centre, half-width, feather, sat,   hue-shift, value
    (120.0,  55.0, 25.0, 0.88,  -8.0, 0.97),   # foliage  -> olive, darker
    (228.0,  45.0, 25.0, 1.00,  -5.0, 1.00),   # sky      -> kill purple, keep depth
    (320.0,  50.0, 30.0, 0.92,  +2.0, 1.00),   # magenta  -> calm
    ( 35.0,  40.0, 30.0, 1.03,   0.0, 1.00),   # warm     -> kept alive
]


def clamp01(x):
    return 0.0 if x < 0.0 else (1.0 if x > 1.0 else x)


def shoulder(x):
    """Soft highlight roll-off: identity below START, compresses above it."""
    if x <= SHOULDER_START:
        return x
    t = (x - SHOULDER_START) / (1.0 - SHOULDER_START)
    return SHOULDER_START + (1.0 - SHOULDER_START) * (t ** SHOULDER_K)


def rgb_to_hsv(r, g, b):
    mx = max(r, g, b)
    mn = min(r, g, b)
    d = mx - mn
    if d == 0.0:
        h = 0.0
    elif mx == r:
        h = 60.0 * (((g - b) / d) % 6.0)
    elif mx == g:
        h = 60.0 * (((b - r) / d) + 2.0)
    else:
        h = 60.0 * (((r - g) / d) + 4.0)
    s = 0.0 if mx == 0.0 else d / mx
    return h, s, mx


def hsv_to_rgb(h, s, v):
    h = h % 360.0
    c = v * s
    x = c * (1.0 - abs((h / 60.0) % 2.0 - 1.0))
    m = v - c
    i = int(h // 60.0) % 6
    if i == 0:
        rp, gp, bp = c, x, 0.0
    elif i == 1:
        rp, gp, bp = x, c, 0.0
    elif i == 2:
        rp, gp, bp = 0.0, c, x
    elif i == 3:
        rp, gp, bp = 0.0, x, c
    elif i == 4:
        rp, gp, bp = x, 0.0, c
    else:
        rp, gp, bp = c, 0.0, x
    return rp + m, gp + m, bp + m


def band_weight(h, centre, half, feather):
    """Smooth 0..1 window around `centre`, feathered at both ends."""
    dist = abs(((h - centre + 180.0) % 360.0) - 180.0)
    if dist >= half:
        return 0.0
    if dist <= half - feather:
        return 1.0
    t = (half - dist) / feather                      # 0..1 approaching centre
    return 0.5 - 0.5 * math.cos(math.pi * t)          # cosine ramp


def grade(r, g, b):
    # --- 1. highlight shoulder -------------------------------------------
    r, g, b = shoulder(r), shoulder(g), shoulder(b)

    # --- 2. split tone (by luma) -----------------------------------------
    luma = 0.2126 * r + 0.7152 * g + 0.0722 * b
    delta = luma - 0.5
    r += SPLIT_R * delta
    g += SPLIT_G * delta
    b += SPLIT_B * delta

    # --- 3/4. hue shaping + global saturation ----------------------------
    h, s, v = rgb_to_hsv(clamp01(r), clamp01(g), clamp01(b))
    if s > 0.0:
        for centre, half, feather, sat_mul, hue_shift, val_mul in HUE_BANDS:
            w = band_weight(h, centre, half, feather)
            if w <= 0.0:
                continue
            s *= (1.0 - (1.0 - sat_mul) * w)
            h += hue_shift * w
            v *= (1.0 - (1.0 - val_mul) * w)
        s = clamp01(s * GLOBAL_SAT)
        r, g, b = hsv_to_rgb(h, s, v)

    # --- 5. black floor --------------------------------------------------
    r = BLACK_FLOOR + r * (1.0 - BLACK_FLOOR)
    g = BLACK_FLOOR + g * (1.0 - BLACK_FLOOR)
    b = BLACK_FLOOR + b * (1.0 - BLACK_FLOOR)

    return clamp01(r), clamp01(g), clamp01(b)


def build_lut():
    img = Image.new("RGB", (WIDTH, HEIGHT))
    px = img.load()
    for t in range(TILES):
        blue = t / STEPS
        for j in range(TILE):
            green = j / STEPS
            for i in range(TILE):
                red = i / STEPS
                r, g, b = grade(red, green, blue)
                px[t * TILE + i, j] = (
                    int(round(r * 255.0)),
                    int(round(g * 255.0)),
                    int(round(b * 255.0)),
                )
    return img


def self_test(img):
    """Sanity checks against the identity convention."""
    px = img.load()

    # neutral grey axis must stay neutral-ish
    for k in (0, 8, 16, 24, 31):
        r, g, b = px[k * TILE + k, k]
        assert abs(r - g) <= 6 and abs(g - b) <= 6, (k, r, g, b)

    # black must have the floor (keeps the LUT pass NaN-safe downstream)
    r, g, b = px[0, 0]
    assert 1 <= r <= 3 and 1 <= g <= 3 and 1 <= b <= 6, (r, g, b)

    # white must still be white (no crushed highlights)
    r, g, b = px[31 * TILE + 31, 31]
    assert r >= 250 and g >= 250 and b >= 250, (r, g, b)

    # greens must be less saturated than the source
    _, s_src, _ = rgb_to_hsv(0.35, 0.62, 0.30)
    r, g, b = px[10 * TILE + int(round(0.35 * 31)), int(round(0.62 * 31))]
    _, s_out, _ = rgb_to_hsv(r / 255.0, g / 255.0, b / 255.0)
    assert s_out < s_src, (s_src, s_out)


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "Textures", "lut.png")
    img = build_lut()
    self_test(img)
    img.save(out)
    print("wrote %s (%dx%d)" % (out, img.size[0], img.size[1]))


if __name__ == "__main__":
    main()
