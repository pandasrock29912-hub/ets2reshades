# ETS2 :: PHOTOREALISM — ReShade preset

A tuned ReShade preset for **Euro Truck Simulator 2** built to kill the three
things that instantly read as "game": flat filtered contrast, oversaturated
plastic colour, and aliased/banded edges. What's left is tone, glass and
sensor behaviour — the stuff that makes people ask which camera you shot it on.

---

## What's in here

| File | What it is |
|---|---|
| `ETS2_Photorealism.ini` | **Tier 1 / Core.** Uses only the two effect packs ReShade ticks by default. Works out of the box, cheapest. |
| `ETS2_Photorealism_MAX.ini` | **Tier 2.** Tier 1 + real highlight bloom, statistical chroma spread, Perlin film grain. Needs the *"Legacy effects"* pack. |
| `ETS2_Premium.ini` | **Tier 3 / Premium.** SweetFX chain replaced with best-in-class: iMMERSE SMAA, eye adaptation, qUINT Lightroom develop, qUINT bloom, Clarity, Smart_Sharp, prod80 radial CA + film grain. See `README_PREMIUM.md`. |
| `ETS2_Premium_Depth.ini` | **Tier 4 / Premium Depth.** Tier 3 + MXAO contact shadows, aerial-perspective haze, sun streak and a Ctrl+Shift+P photo-mode DOF. Needs the depth buffer (5-min setup, in `README_PREMIUM.md`). |
| `Textures/lut.png` | The camera profile (1024×32 strip LUT). This is the colour character layer. All four presets use it. |
| `Textures/lut_stock_identity.png` | ReShade's original neutral LUT, kept so you can restore it. |
| `Tools/generate_lut.py` | Source for the LUT — tweak it and regenerate (`python3 Tools/generate_lut.py`). |
| `Tools/validate_preset.py` | Checks a preset against the `.fx` sources: wrong technique names, mistyped sliders, missing vector components. |

**Tiers 1 and 2 use no depth buffer**, so there is nothing to configure in
ReShade's depth-buffer list, and nothing here breaks if ReShade can't read
ETS2's depth. Tier 4 does — it's a separate preset for exactly that reason.

---

## Install (5 minutes)

### 1. ReShade

1. Download the installer from **<https://www.reshade.me/>** → `ReShade_Setup.exe`.
2. Point it at your game exe:
   `…\steamapps\common\Euro Truck Simulator 2\bin\win_x64\eurotrucks2.exe`
   (older 32-bit builds used `bin\win_x86` — if the installer doesn't find it,
   just browse to whichever `eurotrucks2.exe` your install actually has)
3. Rendering API → **Direct3D 10/11** (default renderer). Pick **OpenGL** only
   if you've switched ETS2 to OpenGL in its graphics options.
4. On the effects page, press **Browse…** and pick the preset you want
   (`ETS2_Photorealism.ini` or `_MAX.ini`). The installer reads the
   `Technique@File.fx` entries and **auto-ticks every pack the preset needs**
   — for `_MAX` that means *Legacy effects*.
5. Leave **Standard effects** and **SweetFX by CeeJay.dk** ticked if you're
   browsing by hand. You do **not** want add-ons for this preset.
6. Install.

> Installing by hand later? Put `d3d11.dll` (that's `ReShade64.dll` renamed)
> next to `eurotrucks2.exe`, and drop the whole `reshade-shaders` folder next
> to it too.

### 2. The LUT texture

Copy `Textures/lut.png` into the game's texture folder, overwriting the stock one:

```
Euro Truck Simulator 2/reshade-shaders/Textures/lut.png
```

ReShade's stock `lut.png` is a **neutral identity texture** (I checked all
32,768 of its entries — it maps every colour to itself), so overwriting it
breaks nothing and `lut_stock_identity.png` puts the original back.

Skip this step and the `LUT` technique just does nothing — the rest of the
preset still works.

### 3. Load it in game

Launch ETS2, press **Home** → the ReShade overlay opens → **Home** tab →
pick the preset in the dropdown. It stays selected across launches.

ReShade hotkeys worth binding in *Settings → Input*:
- **Effects toggle** — flip the whole preset on/off for a before/after
- **Screenshot** (default `PrtScn`) — saves the *post-processed* frame as PNG

---

## Pair it with these game settings

ReShade can only re-grade pixels that exist. These matter more than any slider
in the preset:

| Setting | Why |
|---|---|
| **Scaling → 150–200%** | ETS2's scaling is supersampling. This is the single biggest realism win there is — it removes shimmer, thins aliasing and makes textures resolve like a photo. |
| **Anti-aliasing → TAA** (if your build has it) | Let the game handle temporal shimmer, let SMAA handle what TAA misses. If you only have FXAA, leave it **off** — SMAA in the preset is cleaner. |
| **Anisotropic filtering → 16×** | Road surfaces staying sharp into the distance is a dead giveaway either way. |
| **Shadows / reflections → High or Ultra** | Hard, detailed shadows and accurate light bounce are what separate "photo" from "render". |
| **Overall & mesh/texture quality → High/Ultra** | Low LODs will show through any amount of grading. |
| **Brightness/contrast → default** | The preset sets its own black point (`Levels 6/246`). Don't double-dip. |

**For the shot itself:** overcast, dawn/dusk, or wet roads photograph far
better than flat noon light. Overcast is the closest thing to a real photo
lighting setup — soft, directionless, high dynamic range in colour.

---

## How the chain works

Order matters. Applied top → bottom:

| # | Technique | Job |
|---|---|---|
| 1 | **SMAA** | Colour-edge anti-aliasing. Catches thin geometry (mirror arms, rigging, guard rails) luminance detection misses. |
| 2 | **LiftGammaGain** | White balance: cool shadows, warm gain, neutral mid. Also leaves a 0.01 floor on pure black so the LUT below never hits `normalize(0)` — **keep it enabled**. |
| 3 | **LUT** | The camera profile: highlight shoulder, split tone, foliage → olive & darker, sky keeps its depth (game-purple nudge removed), global chroma ×0.94. |
| 4 | **Levels** | Real sensor black point (6/246). Deep, not crushed. |
| 5 | **Curves** | Gentle filmic S — **Luma mode only**, so contrast never shifts hue (that's what makes filters look like filters). |
| 6 | **Tonemap** | 10% bleach-bypass: the silvery highlight sheen film has. |
| 7 | **Vibrance** | Saturation discipline — only the *muted* colours get a nudge. |
| 8 | **Colourfulness** *(MAX only)* | Chroma **spread** rather than a flat boost: grey stays grey, colour gains life. |
| 9 | **Bloom** *(MAX only)* | Real highlight glare above 0.88 — sun, headlights, wet asphalt. Flares, godrays and lens dirt are deliberately **off**; they're the classic "ReShade screenshot" tell. |
| 10 | **CAS** | AMD FidelityFX contrast-adaptive sharpening. Recovers TAA/scaling softness without halos on foliage or HUD. |
| 11 | **Vignette** | ~8% corner falloff at 16:9, centre untouched. A fast lens, not a filter. |
| 12 | **CA** | ~0.25px sub-pixel fringe. You should only ever notice it on high-contrast corners. |
| 13 | **Deband** | Runs last-but-one on purpose — Levels/Curves/Vignette all re-expand 8-bit values and re-band a gradient sky. |
| 14 | **FilmGrain** / **FilmGrain2** *(MAX)* | ~1% texture in shadows/midtones, and it dithers gradients so they can't band. |

---

## Tuning: "it looks…"

Everything is in the ReShade overlay under each shader's section. Common fixes:

| Complaint | Turn this |
|---|---|
| Too dark / crushed shadows | `[Levels] BlackPoint` → 0, and/or `[Curves] Contrast` → 0.20 |
| Too bright / washed out | `[Levels] WhitePoint` → 252, `[Tonemap] Exposure` → 0.00 |
| Flat, needs more punch | `[Curves] Contrast` → 0.38 (cap ~0.45 before it looks graded) |
| Too warm / too cold | `[LiftGammaGain] RGB_Gain` — raise R & lower B for warm, reverse for cool |
| Greens look neon | `[LUT] fLUT_AmountChroma` → 0.6, or regenerate the LUT with a stronger `HUE_BANDS` green entry |
| Sky banding still visible | `[Deband] iterations` → 2, or `[FilmGrain] Intensity` → 0.06 |
| HUD text gets fuzzy | `[CAS] Sharpening` → 0.40, and/or `[SMAA] EdgeDetectionThreshold` → 0.10 |
| Corners too dark | `[Vignette] Amount` → -0.40 |
| Grain visible/annoying | `[FilmGrain] Intensity` → 0.000 (or delete the technique from `Techniques=`) |
| Colours look filtered | `[LUT] fLUT_AmountChroma` → 0.5, `[Vibrance] Vibrance` → 0.00 |
| Bloom looks milky | `[Bloom] fBloomThreshold` → 0.94, `fBloomAmount` → 0.30 |
| FPS too low | Disable in this order: **Bloom → Deband → SMAA → CAS**. The four 1-tap grades (Levels, Curves, Vibrance, LGG) are essentially free. |

After editing the `.ini` by hand, check it:

```bash
python3 Tools/validate_preset.py ETS2_Photorealism.ini --shaders "…/Euro Truck Simulator 2/reshade-shaders/Shaders"
```

It reproduces ReShade's parser, so it catches the failures that otherwise
fail silently: a mistyped technique (the whole effect just doesn't enable), a
renamed slider (silently keeps the default), or a `float3` written with two
values (**the missing third component defaults to 0** — a classic way to turn
your sky green).

---

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Preset not in the dropdown | It must end in `.ini`/`.txt` **and** have a `Techniques=` line before any `[Section]`. Both shipped presets do. |
| *"uses unknown technique"* in the log | A pack isn't installed. `_MAX` needs **Legacy effects** — re-run the installer and tick it (or browse to the preset so it auto-ticks). |
| Whole image breaks / speckles in dark areas | `LUT.fx` computes `normalize()` on the input colour; pure `(0,0,0)` pixels go NaN. Keep **LiftGammaGain** enabled — its blue lift is what guarantees there are no pure-black pixels. |
| LUT did nothing | You skipped step 2 (the stock file is identity, so it's a no-op). |
| Changes don't apply | Hit **Reload** in the overlay; also make sure *Settings → Performance mode* isn't holding values as compile-time constants mid-edit. |
| Preset reverts / won't save | The game folder or `ReShade.ini` isn't writable (common if Windows/OneDrive owns the path). |
| Text/overlay flicker | SMAA or CAS interacting with the HUD: raise `EdgeDetectionThreshold` or lower `CAS.Sharpening`. |

**Uninstall:** delete `d3d11.dll` (or `opengl32.dll`) from the game folder.
Leave or delete `reshade-shaders` and `ReShade.ini` as you like.

---

## Credits

Shaders are the standard ReShade packs: SweetFX / SMAA / CAS / Curves /
LiftGammaGain (CeeJay.dk), LUT (Marty McFly), Deband + LUT texture (ReShade),
Colourfulness / Bloom / FilmGrain2 (ReShade legacy set). This preset is the
tuning, the chain order, the ETS2 pairing and the generated LUT profile.
