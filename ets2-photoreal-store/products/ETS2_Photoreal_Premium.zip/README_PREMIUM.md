# ETS2 :: PHOTOREALISM PREMIUM — ReShade presets

Two presets that replace the SweetFX chain with the best-in-class shader for
each job, and (in the DEPTH build) add the three things only a depth buffer
can do: ambient occlusion, aerial perspective and a photo-mode lens.

| File | What it is | Depth needed |
|---|---|---|
| `ETS2_Premium.ini` | **Premium.** Eye adaptation, a real develop pass, physically-plausible bloom, micro-contrast, radial lens CA, film grain. | No |
| `ETS2_Premium_Depth.ini` | **Premium Depth.** Everything above **+ MXAO contact shadows + distance haze + sun streak + Ctrl+Shift+P photo-mode DOF.** | **Yes** |
| `Textures/lut.png` | The same camera profile both presets use. | — |
| `Tools/validate_preset.py` | Preset linter (catches what ReShade fails silently on). | — |

If you just want to install and forget: **start with `ETS2_Premium.ini`**.
Move to the DEPTH build once you've done the 5-minute depth calibration below.

---

## What changed vs Tier 1/2, and why

Every SweetFX pass here was replaced by a shader that does the same job
better. Nothing was added for the sake of adding.

| Job | Tier 1/2 used | Premium uses | Why it's better |
|---|---|---|---|
| Anti-aliasing | SweetFX **SMAA** | **iMMERSE SMAA** (Marty's rewrite) | Better corner/geometry handling, higher quality search, and depth-predicated thresholds in the DEPTH build — so it can be aggressive on the truck without eating the HUD. |
| Exposure | fixed | **EyeAdaption** (brussell) | The frame's own average luminance drives exposure like a camera meter. Tunnels, forest shade and dusk now read as *changing light*, not a static filter. |
| Develop / grade | Levels + Curves + Tonemap + Vibrance + LGG (5 passes) | **qUINT Lightroom** + LiftGammaGain (2 passes) | Lightroom is a proper tone pipeline — exposure, toe/shoulder curves, contrast, vibrance, white balance and a lens vignette, all luma-aware so hue never shifts — and it replaces the SweetFX vignette with a real circular falloff. LGG stays for the split tone and the black floor the LUT needs. |
| Sharpening | **CAS** | **Smart_Sharp** (AstrayFX) | Contrast-adaptive *and* depth-aware in the DEPTH build: background and sky are excluded, so distant foliage doesn't shimmer. |
| Chromatic aberration | SweetFX linear shift | **prod80 radial CA** | Zero at the optical centre, growing to the corners — the way a real lens behaves. SweetFX's is a uniform shift across the whole frame, which is what makes it look like a filter. |
| Deband | SweetFX **Deband** | **qUINT Deband** | Smarter search radius + automated bit depth. |
| Grain | SweetFX **FilmGrain** | **prod80 Film Grain** | Separate highlight/shadow grain weight (film grain is coarser in shadows), grain size/blur/motion control, and mostly-monochrome grain like silver halide. |
| Local contrast | — | **Clarity** (AstrayFX) | The "3D pop": wide-radius micro-contrast that gives truck panels and road texture form, with blend-If guards keeping it out of shadows and clipped highlights. |
| Bloom | Legacy **Bloom** (MAX only) | **qUINT Bloom** | Multi-layer bloom with scene adaptation and tonemap compression — light *bleeds* the way a lens does instead of pasting a glow on top. |

**Depth build adds**

| Effect | What it buys you in ETS2 |
|---|---|
| **iMMERSE MXAO** | Contact shadows. Under the truck, in the wheel arches, between trailers. This is what makes objects sit *on* the road instead of floating over it. |
| **OtisFX DepthHaze** | Aerial perspective. Distant hills desaturate and soften the way real air does. ETS2's long sight lines are the best possible use of this. |
| **AstrayFX Flair** | A star streak when you drive into the sun, auto-scaled to the sun's actual on-screen brightness. |
| **OtisFX CinematicDOF** | Photo mode: disc bokeh, anamorphic highlights, focus follows the mouse. Off by default — **Ctrl+Shift+P** to shoot. |

---

## Install

### 1. ReShade + packages

1. Installer from **<https://www.reshade.me/>** → `ReShade_Setup.exe`.
2. Game exe: `…\steamapps\common\Euro Truck Simulator 2\bin\win_x64\eurotrucks2.exe`.
3. Rendering API → **Direct3D 10/11**.
4. Press **Browse…** and pick the preset. The installer reads the
   `Technique@File.fx` entries and **auto-ticks every pack it needs**.

Browsing by hand instead? These are the exact packs:

| Pack | `ETS2_Premium.ini` | `ETS2_Premium_Depth.ini` |
|---|---|---|
| `[00]` Standard effects | auto (required) | auto (required) |
| `[01]` SweetFX by CeeJay.dk | auto (ticked by default) | auto (ticked by default) |
| `[03]` OtisFX by Otis_Inf | — | ☑ |
| `[07]` Shaders by brussell | ☑ | ☑ |
| `[09]` qUINT by Marty McFly | ☑ | ☑ |
| `[12]` Color effects by prod80 | ☑ | ☑ |
| `[16]` AstrayFX by BlueSkyDefender | ☑ | ☑ |
| `[23]` iMMERSE by Marty McFly | ☑ | ☑ |

### 2. The LUT texture

Same as before — copy `Textures/lut.png` over the stock one:

```
Euro Truck Simulator 2/reshade-shaders/Textures/lut.png
```

### 3. DEPTH BUILD ONLY — point ReShade at the depth buffer (5 min, once)

The DEPTH preset reads the z-buffer. ETS2 doesn't hand it over automatically,
so tell ReShade which buffer to use. Do this once — it sticks.

**Step 1 — pick the buffer.** Open the overlay → **Add-ons** tab →
**Generic Depth**. The list shows every depth buffer with its resolution,
draw-call count and vertex count. Pick the one whose draw calls are highest
and whose resolution matches your output. Two checkboxes matter:

* ☑ **Copy depth buffer before clear operations** — tick it if the depth
  preview looks empty or flickers (ETS2 clears depth mid-frame in some
  weather/lighting states).
* ☑ **Copy depth buffer before fullscreen draw calls** — only if the above
  alone still leaves artifacts.

> Don't see a "Generic Depth" section at all? Add-ons are disabled — ReShade is
> running in safe mode, the add-on was unticked, or whatever you're running
> blocks add-ons. Use `ETS2_Premium.ini` instead; it needs none of this.

**Step 2 — check the orientation.** Enable the **DisplayDepth** technique
(Standard effects). You must see the 3D scene as a depth image: near = dark,
far = bright, no stripes, no garbage.

Then fix whatever is wrong using **Home tab → "Edit global preprocessor
definitions"** (the button is at the top of the effect list) — **not** the
sliders inside DisplayDepth, those only change its own preview:

| Preview looks like | Set |
|---|---|
| Upside down | `RESHADE_DEPTH_INPUT_IS_UPSIDE_DOWN=1` |
| Near is bright / white, far is black | `RESHADE_DEPTH_INPUT_IS_REVERSED=1` |
| Stripey or garbage, but right way up | `RESHADE_DEPTH_INPUT_IS_LOGARITHMIC=1` |

Put them in the **Current Preset** column so they're saved into the `.ini`.
Then turn **DisplayDepth off** — it never needs touching again unless you
change resolution scaling.

**Step 3 — sanity check.** With the DEPTH preset on, look at the ground under
your truck: there should be a soft dark contact shadow, and distant hills
should be slightly softer/hazier than the road. If AO looks like thick black
paint, lower `MXAO_SSAO_AMOUNT`. If the far distance looks fogged out, lower
`DepthHaze EffectStrength` first.

---

## Photo mode

`ETS2_Premium_Depth.ini` ships `CinematicDOF` **disabled** but positioned last
in the chain, on **Ctrl+Shift+P**:

1. Enter ETS2's screenshot/photo camera (or free camera).
2. Press **Ctrl+Shift+P** — focus follows the mouse, 85mm f/2.8 disc bokeh.
3. Shoot (ReShade's **Screenshot** hotkey saves the *post-processed* frame).
4. Press **Ctrl+Shift+P** again to go back to normal driving.

Rebind it in the Home tab: click the shortcut field next to `CinematicDOF`
and press your key. It's `key,ctrl,shift,alt` in the `.ini`
(`80,1,1,0` = P + Ctrl + Shift).

---

## How the chain works

Applied top → bottom. This order is deliberate:

| # | Technique | Job |
|---|---|---|
| 1 | **MartysMods_AntiAliasing_Prepass** + **MartysMods_AntiAliasing** | Two passes from one file — prepass builds the edge buffers, second blends. They must stay adjacent and in this order. |
| 2 | **MXAO** *(depth only)* | Occlusion is scene lighting, so it goes before any grading. |
| 3 | **EyeAdaption** | Metering the raw frame before anything else grades it. |
| 4 | **Lightroom** | The develop: exposure, curves, contrast, vibrance, white balance, vignette. |
| 5 | **LiftGammaGain** | Split tone (cool shadows, warm gain) **and** the black floor the LUT needs — see the note below. |
| 6 | **LUT** | The camera profile (hue/chroma character). Lightroom owns tone, LUT owns colour — nothing is graded twice. |
| 7 | **Clarity** | Micro-contrast on the graded image. |
| 8 | **DepthHaze** *(depth only)* | Atmosphere, after the grade so it reads as air rather than a filter. |
| 9 | **Bloom** | Veiling glare — light bleeding out of the bright areas. |
| 10 | **Flair** *(depth only)* | Sun streak, on top of the bloom. |
| 11 | **Smart_Sharp** | Sharpening last-but-few, so it isn't undone by anything downstream. Depth-aware in the DEPTH build. |
| 12 | **prod80 CA** | Lens dispersion — a lens effect, near the end. |
| 13 | **Deband** | Everything above re-expands 8-bit values and re-bands a gradient sky. |
| 14 | **prod80 Film Grain** | Silver-halide texture, and it dithers so the debanded sky can't band again. |
| 15 | **CinematicDOF** *(depth only, Ctrl+Shift+P)* | Always last — DoF applies to the finished frame. |

**Why LiftGammaGain is still in there (don't delete it):** `LUT.fx` computes
`normalize(color)`, and a pure `(0,0,0)` pixel is `normalize(0)` = NaN — a
night scene can break the whole frame. `Lightroom` can't help (its tone curve
is `pow(x, k)`, and `0^k` is still 0), so LiftGammaGain's blue lift of 1.018
puts a floor of ~2/255 under the blue channel. Invisible, always &gt; 0.
It also does the split tone, which is the film/print signature.

---

## Tuning: "it looks…"

Everything is in the overlay under each shader's section. The knobs that
actually matter, in the order to try them:

| Complaint | Turn this |
|---|---|
| Whole thing too dark / too bright | `Lightroom → Global Exposure` (±0.15 is a lot) |
| Shadows crushed | `Lightroom → Global Blacks Curve` → 0.00, `Shadows Curve` → 0.10 |
| Highlights blown / milky | `Lightroom → Global Highlights Curve` → -0.10; then `Bloom → Bloom Curve` → 2.5 |
| Too warm / too cold | `Lightroom → Global Temperature` (+ = warmer, - = cooler) |
| Colours too muted / too vivid | `Lightroom → Global Vibrance` (0.0–0.30), or `LUT → LUT chroma amount` |
| Not enough "pop" | `Clarity → Clarity Strength` → 0.50 (stop at 0.65, past that it's an HDR filter) |
| Haloing on truck edges | `Clarity → Clarity Dark Intensity` → 0.20, or `Clarity Light Intensity` back to 0 |
| Bloom looks milky | `Bloom → Bloom Intensity` → 0.50, `Bloom Curve` → 2.5 |
| Corners too dark | `Lightroom → Vignette Amount` → 0.20, or `Enable Vignette` off |
| Grain visible/annoying | `Film Grain → Grain Intensity` → 0.10, or 0.00 to kill it |
| Sky banding | `qUINT_deband → Search Radius` → 0.8, `Debanding` mode → 2 if you changed it |
| HUD text gets fuzzy | `SMAA → SMAA Threshold` → 0.10, `Smart_Sharp → Sharpness` → 0.40 |
| **DEPTH:** AO looks like black paint | `MXAO → Ambient Occlusion Amount` → 0.40, `Sample Radius` → 1.5 |
| **DEPTH:** AO shimmers while driving | `MXAO → Shading Rate` → 0 (Full Rate), `Filter Quality` → 2 |
| **DEPTH:** far distance too foggy | `DepthHaze → Effect Strength` → 0.15, `Fog Factor` → 0.08 |
| **DEPTH:** sun streak everywhere | `Flair → Flare Brightness Threshold` → 0.95, or `Flare Intensity` → 0.0 |
| **DEPTH:** DOF too strong | `CinematicDOF → FNumber` → 4.0 (deeper focus) |

After hand-editing the `.ini`, check it:

```bash
python3 Tools/validate_preset.py ETS2_Premium.ini ETS2_Premium_Depth.ini \
    --shaders "…/Euro Truck Simulator 2/reshade-shaders/Shaders"
```

It reproduces ReShade's parser, so it catches the mistakes that otherwise
fail silently: a mistyped technique (the effect just never enables), a
renamed slider (silently keeps its default), or a `float3` written with two
values — **the missing component defaults to 0**, which is a classic way to
turn your sky green.

---

## Performance

Rough cost ranking, most expensive first. If you need frames, disable in this
order — you lose the least realism per frame this way:

1. **CinematicDOF** (photo mode only — leave it off while driving)
2. **MXAO** (quality preset is the knob: `MXAO Sample Quality` → 1 = Medium)
3. **Bloom** (multi-layer)
4. **Flair** (`Flare Intensity` → 0)
5. **Smart_Sharp**
6. **SMAA** (lower `Max Search Steps` to 32 before disabling)

The colour/tone passes (EyeAdaption, Lightroom, LUT, Clarity, CA, Deband,
Grain) are all cheap — disabling them costs you most of the look for
almost no FPS.

---

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| *"uses unknown technique"*, or an effect shows as missing | A pack isn't ticked. Re-run the installer and browse to the preset so it auto-ticks (table above), or tick the pack by hand. |
| **DEPTH:** depth preview empty / black | Wrong buffer, or it's cleared mid-frame. Re-pick in Add-ons → Generic Depth and tick **Copy depth buffer before clear operations**. |
| **DEPTH:** AO or haze on the *HUD* | The HUD has no depth, so it inherits the depth of whatever is behind it. That's expected. Keep DOF off while driving; if it bothers you, disable `DepthHaze` and keep `MXAO`. |
| **DEPTH:** everything looks like it has "double edges" / ringing | `Smart_Sharp` depth mask fighting a mis-oriented depth buffer. Re-run the DisplayDepth calibration. |
| Whole image breaks, speckles in dark areas | `LUT.fx` runs `normalize()` on its input; a pure `(0,0,0)` pixel goes NaN. The guard is `LiftGammaGain` (blue lift 1.018) — if you disabled it, put it back. |
| Dark areas lost all detail | `Lightroom → Global Blacks Curve` is doing the crushing — set it to 0.00, and check `Global Contrast` isn't above 0.25. |
| Changes don't apply | Hit **Reload**; also check *Settings → Performance mode* isn't holding values as compile-time constants mid-edit. |
| Preset reverts / won't save | The game folder or `ReShade.ini` isn't writable (common when Windows/OneDrive owns the path). |
| Add-ons section missing | ReShade is in safe mode, or the add-on is unticked. Use `ETS2_Premium.ini`. |

**Uninstall:** delete `d3d11.dll` from the game folder. Leave or delete
`reshade-shaders` and `ReShade.ini` as you like.

---

## Credits

Shaders by their authors — this preset is the selection, the chain order, the
pairing with ETS2 and the numbers:

* **Marty McFly** — qUINT (Lightroom, Bloom, Deband), iMMERSE (SMAA, MXAO)
* **BlueSkyDefender** — AstrayFX (Clarity, Smart_Sharp, Flair)
* **prod80** — Chromatic Aberration, Film Grain
* **brussell** — EyeAdaption
* **Otis_Inf** — OtisFX (DepthHaze, CinematicDOF)
* **CeeJay.dk / luluco250 / ReShade team** — SMAA/LUT/Deband lineage, LUT texture
